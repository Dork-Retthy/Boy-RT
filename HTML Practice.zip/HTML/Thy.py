i = 0
while i <= 30:
    print(i)
    i = i + 1

n = 0
sum = 0
while n <= 15:
    sum += n
    n = n + 1
    print(sum)

n = 0 
while n <= 15:
    if n % 2 == 0:
        print(n)
    n += 1

n = 0
while n <= 15:
    if n % 2 ==1:
        print(n)
    n += 1

n = 0
sum = 0
while n <= 15:
    if n % 2 == 1:
        sum += n
    n = n + 1
print(sum)
    